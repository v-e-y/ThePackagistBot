Hello. This is the telegram bot code. This bot will give you a certain amount of packages based on the tag you give to the team.

## Do not use this code for your bot.  
## This code does not follow best coding practices.  
## I'm just learning, so there are a lot of mistakes here, which I will iron out over time.